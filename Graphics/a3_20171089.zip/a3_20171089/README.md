Grpahics Surfers
===================


# Controls
> `a` to go left
> `d` to go right
> `w` to jump

# Boosts
## Jetpack
> R2D2 flies for sometime and can collect coins in air

## Super Sneakers
> R2D2 can wear those and jump over bigger obstacles

# Obstacles
## High Post
> R2D2 cannot jump over it normally
> He can jump with super sneakers
> He can normally stumble and go under in which case the Stormtroopers and Aibo close in

## Low barrier
> R2D2 can jump over it but he cannot go under

