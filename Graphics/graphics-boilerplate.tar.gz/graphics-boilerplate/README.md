In Class Assignment 2
======================

> left to change camera views
> up to move camera in helicopter view