Assignment 2
======================
> ### Controls
> - `c` to change camera views
> - `up` to go up
> - `down` to go down
> - `right click` to drop bombs
> - `left click` to shoot bullets
> - `w` to increase speed
> - `s` to decrease speed
> - `q` to roll left
> - `e` to roll right
> - `move mouse up/down and left/right` in helicopter view to change camera position
