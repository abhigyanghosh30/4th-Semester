#include "main.h"

const color_t COLOR_RED = { 236, 100, 75 };
const color_t COLOR_GREEN = { 135, 211, 124 };
const color_t COLOR_BLACK = { 52, 73, 94 };
const color_t COLOR_BACKGROUND = { 135, 206, 250 };
const color_t COLOR_BLUE = { 77, 77, 255 };
const color_t COLOR_DEEPSEABLUE = { 0, 105, 148 };
const color_t COLOR_LAVAYELLOW = { 207, 16, 32 };
const color_t COLOR_YELLOW = {255, 255, 0};