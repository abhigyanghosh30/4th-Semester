#include "main.h"

const color_t COLOR_RED = { 236, 100, 75 };
const color_t COLOR_GREEN = { 135, 211, 124 };
const color_t COLOR_BLACK = { 52, 73, 94 };
const color_t COLOR_BACKGROUND = { 0, 0, 0 };
const color_t COLOR_YELLOW = { 255, 215, 0 };
const color_t COLOR_BLUE = { 0, 0, 128 };
const color_t COLOR_GOLD = { 187, 165, 89 };
const color_t COLOR_BROWN = { 165, 42, 42 };
const color_t COLOR_SILVER = { 192, 192, 192 };