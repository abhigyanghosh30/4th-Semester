JETPACK JOYRIDE
===============

Controls:
==========
> - `UP-KEY` : To make the player jump
> - `RIGHT_KEY` : To make the player go right
> - `LEFT_KEY` : To make the player go left
> - `SPACEBAR` : To throw water balloons (works only when the player is in motion)
> - `Q` or `ESC` : To quit
> - `MOUSE SCROLL` : To zoom in and out 