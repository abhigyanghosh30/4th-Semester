File Server
==============

# Server
> `cd server` to go to the server directory
> **Files served by the sever should be in this directory only. Doesnt support iterative listing.**
> `gcc server.c -o server` to compile
> `./server` to start the server
>

# Client
> `cd client` to go to the client directory
> `gcc client.c -o client` to compile
> `./client` to start the client
> files downloaded by client will be stored in this directory