Assignment 2
==============

# Server
`cd server` to go to the server directory
`gcc server.c -o server` to compile
`./server` to start the server


# Client
`cd client` to go to the client directory
`gcc client.c -o client` to compile
`./client` to start the client